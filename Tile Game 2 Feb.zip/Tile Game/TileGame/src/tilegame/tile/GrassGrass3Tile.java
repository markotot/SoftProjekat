package tilegame.tile;

import tilegame.gfx.Assets;

public class GrassGrass3Tile extends Tile {
	
	public GrassGrass3Tile(int id){
		super(Assets.grassGrass3, id);
	}
}
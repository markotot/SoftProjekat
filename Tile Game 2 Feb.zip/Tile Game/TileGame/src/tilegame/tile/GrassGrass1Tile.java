package tilegame.tile;

import tilegame.gfx.Assets;

public class GrassGrass1Tile extends Tile {
	
	public GrassGrass1Tile(int id){
		super(Assets.grassGrass1, id);
	}
}

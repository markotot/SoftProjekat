package tilegame.tile;

import tilegame.gfx.Assets;

public class GrassGrass2Tile extends Tile {
	
	public GrassGrass2Tile(int id){
		super(Assets.grassGrass2, id);
	}
}
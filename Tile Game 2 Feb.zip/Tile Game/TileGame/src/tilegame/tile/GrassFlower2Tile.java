package tilegame.tile;

import tilegame.gfx.Assets;

public class GrassFlower2Tile extends Tile {
	
	public GrassFlower2Tile(int id){
		super(Assets.grassFlower2, id);
	}
}


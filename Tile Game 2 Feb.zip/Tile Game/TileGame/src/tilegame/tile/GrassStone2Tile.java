package tilegame.tile;

import tilegame.gfx.Assets;

public class GrassStone2Tile extends Tile {
	
	public GrassStone2Tile(int id){
		super(Assets.grassStone2, id);
	}

}


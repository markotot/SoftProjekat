package tilegame.tile;

import tilegame.gfx.Assets;

public class GrassStone4Tile extends Tile {
	
	public GrassStone4Tile(int id){
		super(Assets.grassStone4, id);
	}

}
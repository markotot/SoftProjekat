package tilegame.pathfinding;

public enum TileType {
	PASSABLE, SOLID, START, FINISH, ENEMY, PLAYER, HEART, CHANGED
}

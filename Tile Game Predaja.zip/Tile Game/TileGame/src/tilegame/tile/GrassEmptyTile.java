package tilegame.tile;

import tilegame.gfx.Assets;

public class GrassEmptyTile extends Tile {

	public GrassEmptyTile(int id){
		super(Assets.grassEmpty, id);
	}
	
}

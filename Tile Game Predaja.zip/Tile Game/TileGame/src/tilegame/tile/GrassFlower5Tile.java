package tilegame.tile;

import tilegame.gfx.Assets;

public class GrassFlower5Tile extends Tile {
	
	public GrassFlower5Tile(int id){
		super(Assets.grassFlower5, id);
	}
}


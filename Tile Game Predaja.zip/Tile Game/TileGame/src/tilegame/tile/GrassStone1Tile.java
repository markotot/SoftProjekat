package tilegame.tile;

import tilegame.gfx.Assets;

public class GrassStone1Tile extends Tile {
	
	public GrassStone1Tile(int id){
		super(Assets.grassStone1, id);
	}

}

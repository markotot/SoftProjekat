package tilegame.entities.staticEntities;

import java.awt.Graphics;
import java.awt.Point;

import tilegame.Handler;
import tilegame.entities.Entity;
import tilegame.worlds.World;

public class StaticEntity extends Entity{

	public StaticEntity(Handler handler, float x, float y, int width, int height) {
		super(handler, x, y, width, height);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void tick() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void render(Graphics g) {
		// TODO Auto-generated method stub
		
	}
}

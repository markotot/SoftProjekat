package tilegame.tile;

import tilegame.gfx.Assets;

public class GrassFlower3Tile extends Tile {
	
	public GrassFlower3Tile(int id){
		super(Assets.grassFlower3, id);
	}
}


package tilegame.tile;

import tilegame.gfx.Assets;

public class GrassStone3Tile extends Tile {
	
	public GrassStone3Tile(int id){
		super(Assets.grassStone3, id);
	}

}

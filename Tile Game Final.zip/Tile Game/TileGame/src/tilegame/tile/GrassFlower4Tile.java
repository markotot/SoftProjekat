package tilegame.tile;

import tilegame.gfx.Assets;

public class GrassFlower4Tile extends Tile {
	
	public GrassFlower4Tile(int id){
		super(Assets.grassFlower4, id);
	}
}


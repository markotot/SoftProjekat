package tilegame.tile;

import tilegame.gfx.Assets;

public class GrassFlower1Tile extends Tile {
	
	public GrassFlower1Tile(int id){
		super(Assets.grassFlower1, id);
	}
}
